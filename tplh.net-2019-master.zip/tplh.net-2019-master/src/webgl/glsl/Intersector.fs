precision highp float;

void main() {
  discard;
  gl_FragColor = vec4(1.0);
}
