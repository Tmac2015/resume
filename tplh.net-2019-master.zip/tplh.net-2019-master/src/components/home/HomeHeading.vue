<script>
export default {
  name: 'HomeHeading'
};
</script>

<template lang="pug">
  h1.p-home-heading
    |Yoichi Kobayashi
    br
    |Front-end &amp; Creative Developer
</template>

<style lang="scss">
.p-home-heading {
  display: none;
}
</style>
