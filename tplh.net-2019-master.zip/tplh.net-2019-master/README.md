![ogp image](https://github.com/ykob/tplh.net-2019/blob/master/public/img/ogp_image.png)

# tplh.net

https://www.tplh.net/  
I'm a Web Developer. Just love World-Wide-Web.  
I explored what my identity was and tried to express it as much as possible using whatever technology I have now.

## License

Copyright (c) 2020 Yoichi Kobayashi  
You can refer to these codes and materials, but can't use or quote these for your projects for free.

## Credits

- 3D Models : CGTrader
  - [Low Poly Skull Human VR / AR / low-poly 3d model](https://www.cgtrader.com/3d-models/character/anatomy/low-poly-skull-human)
  - [Petals pack 3D model](https://www.cgtrader.com/3d-models/plant/flower/flying-rose-petals)
- Design : Shunsuke Iseki
- Development : Yoichi Kobayashi

## Award-Winning

- [FWA FOTD / March 14th, 2020](https://thefwa.com/cases/yoichi-kobayashi)
- [Awwwards SOTD / March 23rd, 2020](https://www.awwwards.com/sites/yoichi-kobayashi)

## Misc

Follow Yoichi Kobayashi: [Web](http://www.tplh.net/), [Twitter](https://twitter.com/ykob0123)
